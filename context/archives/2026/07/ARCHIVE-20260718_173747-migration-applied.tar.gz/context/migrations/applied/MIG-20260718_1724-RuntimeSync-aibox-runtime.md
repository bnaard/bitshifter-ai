---
apiVersion: processkit.projectious.work/v1
kind: Migration
metadata:
  id: MIG-20260718_1724-RuntimeSync-aibox-runtime
  created: 2026-07-18 17:24:54+00:00
  updated: '2026-07-18T17:36:09+00:00'
spec:
  source: aibox-runtime-home
  source_url: aibox://runtime-home
  from_version: 0.27.7
  to_version: 0.27.8
  state: applied
  generated_by: aibox apply
  generated_at: 2026-07-18 17:24:54+00:00
  summary: 0 changed upstream, 0 conflicts, 2 new, 0 removed (2 groups affected)
  affected_groups:
  - runtime-git
  - runtime-lazygit
  affected_files:
  - path: .config/git/aibox-github.inc
    classification: new-upstream
  - path: .config/lazygit/config.yml
    classification: new-upstream
  started_at: '2026-07-18T17:36:09+00:00'
  applied_at: '2026-07-18T17:36:09+00:00'
  progress_notes:
  - timestamp: '2026-07-18T17:36:09+00:00'
    actor: mcp
    note: Reviewed as conflict-free and applied during requested pk-doctor remediation.
---

# Migration MIG-20260718_1724-RuntimeSync-aibox-runtime

Managed `.aibox-home/` runtime changes from `0.27.7` to `0.27.8`.

0 changed upstream, 0 conflicts, 2 new, 0 removed (2 groups affected)

## Counts

- unchanged: 40
- changed-locally-only: 0
- changed-upstream-only: 0
- conflict: 0
- new-upstream: 2
- removed-upstream: 0

- removed-upstream-stale: 0

## Changes by group

### runtime-git

**new-upstream**

- `.aibox-home/.config/git/aibox-github.inc` -> `.aibox-home/.config/git/aibox-github.inc`

### runtime-lazygit

**new-upstream**

- `.aibox-home/.config/lazygit/config.yml` -> `.aibox-home/.config/lazygit/config.yml`
